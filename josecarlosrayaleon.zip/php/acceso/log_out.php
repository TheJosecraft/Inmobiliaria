<?php
include '../funciones.php';
log_out();
?>
